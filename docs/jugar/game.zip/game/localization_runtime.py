"""Presentation-only localization. Canonical objects and saved data stay untouched."""
import re
from functools import lru_cache

PERCENT = re.compile(r'(?<!\d)%(?:\([^)]+\))?[#0 +\-]*(?:\d+|\*)?(?:\.(?:\d+|\*))?[hlL]?[sdrifgeEGouxXc%]')
TAGS = re.compile(r'(\{[^{}]*\}|\[\[|\[(?:[^\[\]]|\[[^\]]*\])*\])')

class Presenter:
    def __init__(self, catalogs):
        self.catalogs = catalogs
        self.templates = {}
        self.fragments = {}
        for language, pairs in catalogs.items():
            templates = []
            for old, new in pairs.items():
                matches = list(PERCENT.finditer(old))
                if not matches or any(m.group() == '%%' or m.group().startswith('%(') for m in matches):
                    continue
                # Generic formats such as "%s: %s" cannot identify a language.
                if len(re.sub(r'[^a-zA-ZáéíóúñÁÉÍÓÚÑ]', '', PERCENT.sub('', old))) < 4:
                    continue
                pattern = ''; pos = 0
                for m in matches:
                    pattern += re.escape(old[pos:m.start()])
                    pattern += r'([+-]?\d+(?:\.\d+)?)' if m.group()[-1] in 'difgeEGouxX' else r'(.+?)'
                    pos = m.end()
                pattern += re.escape(old[pos:])
                target = PERCENT.split(new)
                if len(target) != len(matches)+1:
                    continue
                templates.append((len(old), re.compile(r'\A'+pattern+r'\Z', re.S), target))
            self.templates[language] = sorted(templates, key=lambda x:x[0], reverse=True)
            # A single combined regex gives one non-recursive replacement pass.
            # Never translate inside tags, interpolation expressions or other words.
            fragments = {s:t for s,t in pairs.items() if s != t and s.strip() and
                         not PERCENT.search(s) and not any(c in s for c in '{}[]')}
            self.fragments[language] = (re.compile(r'(?:'+'|'.join((('(?<!\\w)' if re.match(r'\w',s[0]) else '') + re.escape(s) + ('(?!\\w)' if re.match(r'\w',s[-1]) else '')) for s in sorted(fragments,key=len,reverse=True))+r')'), fragments)

    def text(self, value, language, player_name='', depth=0):
        if not isinstance(value, str) or language not in self.catalogs or depth > 4:
            return value
        return self._cached(value, language, player_name, depth)

    @lru_cache(maxsize=8192)
    def _cached(self, value, language, player_name, depth):
        pairs = self.catalogs[language]
        if value in pairs:
            return pairs[value]
        # Match grammar before protecting names: a player called "a" must not
        # hide the preposition in "%s golpea a %s por %d.".
        for _, pattern, target in self.templates[language]:
            m = pattern.fullmatch(value)
            if m:
                out = target[0]
                for arg, tail in zip(m.groups(), target[1:]):
                    translated = arg if player_name and arg == player_name else self.text(arg, language, player_name, depth+1)
                    out += translated + tail
                return out
        # In unstructured fragments, protect whole names, not letters inside
        # words ("a" must not break "Espada" or "Arma").
        marker = '\ue000NAME\ue001'
        protected = re.sub(r'(?<!\w)' + re.escape(player_name) + r'(?!\w)', lambda m: marker, value) if player_name else value
        pattern, fragments = self.fragments[language]
        def part(s):
            return pattern.sub(lambda m:fragments[m.group()], s)
        # Preserve text tags and Ren'Py interpolation syntax verbatim.
        out = ''.join(s if i%2 else part(s) for i,s in enumerate(TAGS.split(protected)))
        return out.replace(marker, player_name) if player_name else out
