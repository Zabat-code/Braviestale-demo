"""Rutas fijas de la campaña. Datos compartidos por el juego y el visor local."""

CIUDADES = {
    "BAL": {"nombre": "Puerto Ballenar", "plaza": "puerto_ballenar", "bg": "bg_puerto_ballenar", "prefijo": "bal", "muelle": "muelle_ballenar", "taberna": "taberna_ballenar", "templo": "templo_ballenar", "elemento": "agua", "zona": "puerto_ballenar", "nivel": 15},
    "ROV": {"nombre": "Caleta Rovena", "plaza": "caleta_rovena", "bg": "bg_caleta_rovena", "prefijo": "rov", "muelle": "rov_embarcadero", "taberna": "rov_taberna", "templo": "rov_templo_tierra", "elemento": "tierra", "zona": "caleta_rovena", "nivel": 18},
    "WYN": {"nombre": "Bahía Wyndmere", "plaza": "bahia_wyndmere", "bg": "bg_bahia_wyndmere", "prefijo": "wyn", "muelle": "wyn_varadero", "taberna": "wyn_taberna", "templo": "wyn_templo", "zona": "bahia_wyndmere", "nivel": 22},
    "LUM": {"nombre": "Lumensia", "plaza": "lumenia", "bg": "bg_lumenia", "prefijo": "lum", "muelle": "lum_muelle", "taberna": "lum_taberna", "templo": "lum_templo", "elemento": "aire", "zona": "lumenia", "nivel": 30},
    "SLV": {"nombre": "Slevferia", "plaza": "slevferia", "bg": "bg_slevferia", "prefijo": "slv", "muelle": "slv_muelle", "taberna": "slv_mesa_comun", "templo": "slv_recinto_aire", "zona": "slevferia", "nivel": 32},
    "EXT": {"nombre": "Extenia", "plaza": "extenia", "bg": "bg_extenia", "prefijo": "ext", "muelle": "ext_muelle", "taberna": "ext_taberna", "templo": "ext_templo", "elemento": "luz", "zona": "extenia", "nivel": 25},
    "QAZ": {"nombre": "Quazelia", "plaza": "qaz_plaza", "bg": "bg_quazelia", "prefijo": "qaz", "muelle": "qaz_muelle", "taberna": "qaz_comedor", "templo": "qaz_memorial", "zona": "quazelia_fauna", "nivel": 30},
}

OPUESTO = {"norte": "sur", "sur": "norte", "este": "oeste", "oeste": "este"}
DELTA = {"norte": (0, -1), "sur": (0, 1), "este": (1, 0), "oeste": (-1, 0)}


def construir_mundo():
    nodos, mapas = {}, {}

    def nodo(nid, nombre, xy, mapa, bg, **extra):
        if nid in nodos:
            raise ValueError("Nodo duplicado: " + nid)
        nodos[nid] = dict(nombre=nombre, bg=bg, npcs=[], npc_pos={}, conexiones={}, region_campana=mapa, **extra)
        mapas.setdefault(mapa, {})[nid] = xy

    def unir(a, direccion, b):
        inversa = OPUESTO[direccion]
        for origen, sentido, destino in ((a, direccion, b), (b, inversa, a)):
            anterior = nodos[origen]["conexiones"].get(sentido)
            if anterior and anterior != destino:
                raise ValueError("Conexión ocupada: %s %s" % (origen, sentido))
            nodos[origen]["conexiones"][sentido] = destino

    # Mismo punto de orientación, servicios adaptados y distancias comparables.
    for codigo, c in CIUDADES.items():
        p, pref, bg = c["plaza"], c["prefijo"], c["bg"]
        ids = {"plaza": p, "registro": pref + ("_oficina" if codigo == "QAZ" else "_archivo" if codigo in ("LUM", "SLV") else "_registro"), "botica": pref + "_boticaria", "taberna": c["taberna"], "muelle": c["muelle"], "posada": pref + "_posada", "herreria": pref + ("_taller" if codigo in ("SLV", "QAZ") else "_herreria"), "templo": c["templo"], "camino": pref + "_camino", "salvaje": pref + "_exterior"}
        nombres = {"plaza": "Plaza · " + c["nombre"], "registro": "Oficina de recepción" if codigo == "QAZ" else "Archivo y encargos" if codigo in ("LUM", "SLV") else "Registro y encargos", "botica": "Boticaria técnica" if codigo == "QAZ" else "Boticaria", "taberna": "Comedor" if codigo == "QAZ" else "Mesa común" if codigo == "SLV" else "Taberna", "muelle": "Varadero" if codigo == "WYN" else "Embarcadero" if codigo == "ROV" else "Muelle", "posada": "Casa de huéspedes" if codigo in ("QAZ", "LUM") else "Hospedería" if codigo == "SLV" else "Posada", "herreria": "Taller de circuitos" if codigo == "QAZ" else "Taller y herrería" if codigo == "SLV" else "Herrería", "templo": "Memorial" if codigo == "QAZ" else "Recinto de Aire" if codigo == "SLV" else "Templo local" if codigo == "WYN" else "Templo de " + {"agua":"Agua", "tierra":"Tierra", "aire":"Viento", "luz":"Luz"}[c["elemento"]], "camino": "Camino protegido" if codigo == "QAZ" else "Camino exterior", "salvaje": "Bosque costero" if codigo == "QAZ" else "Bosque de la frontera" if codigo == "SLV" else "Sendero de los patios" if codigo == "LUM" else "Costa de almacenes" if codigo == "ROV" else "Costa abierta"}
        xy = {"plaza": (3,3), "registro": (3,2), "botica": (4,3), "taberna": (2,3), "muelle": (3,4), "posada": (1,3), "herreria": (4,2), "templo": (2,2), "camino": (5,3), "salvaje": (6,3)}
        for servicio, nid in ids.items():
            extra = {"servicio": servicio, "zona": c["zona"], "nivel_zona": c["nivel"]}
            if servicio == "salvaje":
                extra.update(salvaje=True, aviso_bloqueo="Fuera del camino hay criaturas. Puedes volver por la misma ruta.")
            if servicio == "templo" and "elemento" in c:
                extra["elemento_templo"] = c["elemento"]
            fondo = {"muelle":"bg_muelle_ballenar", "taberna":"bg_taberna_ballenar", "templo":"bg_templo_ballenar"}.get(servicio, bg) if codigo == "BAL" else bg
            nodo(nid, nombres[servicio], xy[servicio], codigo, fondo, **extra)
        for a, d, b in (("plaza","norte","registro"),("plaza","sur","muelle"),("plaza","oeste","taberna"),("plaza","este","botica"),("registro","oeste","templo"),("registro","este","herreria"),("taberna","norte","templo"),("botica","norte","herreria"),("taberna","oeste","posada"),("botica","este","camino"),("camino","este","salvaje")):
            unir(ids[a], d, ids[b])
        c["servicios"] = ids

    # Ballenar conserva sus identificadores y añade funciones a la red central.
    nodo("mercado_ballenar", "Mercado de Ballenar", (4,4), "BAL", "bg_mercado_ballenar", npcs_escena=["aldous", "predicadora"])
    unir("bal_boticaria", "sur", "mercado_ballenar")
    unir("muelle_ballenar", "este", "mercado_ballenar")
    nodo("bal_consejo", "Casa del consejo", (3,1), "BAL", "bg_puerto_ballenar")
    unir("bal_registro", "norte", "bal_consejo")
    nodo("playa_ballenar", "Playa de Ballenar", (5,4), "BAL", "bg_playa_ballenar", salvaje=True, zona="puerto_ballenar", nivel_zona=15)
    unir("mercado_ballenar", "este", "playa_ballenar")
    unir("bal_camino", "sur", "playa_ballenar")
    nodo("bal_senales", "Puesto de señales", (6,4), "BAL", "bg_playa_ballenar")
    unir("playa_ballenar", "este", "bal_senales")

    # Rovena: preparar el disfraz antes de entrar; salida visible por el oeste.
    for nid, nombre, xy, kw in (
        ("rov_tejidos", "Tienda de tejidos", (4,1), {}),
        ("rov_reunion", "Salón de la reunión", (3,1), {"requiere":"secta_disfraz"}),
        ("rov_salida_trasera", "Calle trasera", (2,1), {}),
        ("rov_casa_wren", "Casa de Wren y Ralf", (1,2), {}),
        ("rov_pasarela", "Pasarela de almacenes", (5,4), {"salvaje":True, "zona":"caleta_rovena", "nivel_zona":18}),
    ):
        nodo(nid, nombre, xy, "ROV", "bg_caleta_rovena", **kw)
    unir("rov_registro","norte","rov_reunion"); unir("rov_reunion","este","rov_tejidos"); unir("rov_reunion","oeste","rov_salida_trasera")
    unir("rov_tejidos","sur","rov_herreria"); unir("rov_salida_trasera","sur","rov_templo_tierra")
    unir("rov_posada","norte","rov_casa_wren"); unir("rov_templo_tierra","oeste","rov_casa_wren")
    unir("rov_camino","sur","rov_pasarela")

    # Wyndmere: la ciudad es segura; la base tiene un recorrido propio.
    nodo("wyn_casa_orin", "Casa de Orin y Marek", (1,2), "WYN", "bg_bahia_wyndmere")
    unir("wyn_posada","norte","wyn_casa_orin"); unir("wyn_templo","oeste","wyn_casa_orin")
    nodo("wyn_rompeolas", "Rompeolas", (5,2), "WYN", "bg_bahia_wyndmere")
    unir("wyn_camino","norte","wyn_rompeolas")
    for i, (nid, nombre) in enumerate((
        ("wyn_base_entrada","Entrada de la base"), ("wyn_base_depositos","Depósitos de la secta"), ("wyn_base_celdas","Celdas de la base"), ("wyn_base_laboratorio","Cámara de Morwena")
    )):
        nodo(nid,nombre,(3,4-i),"BASE","bg_templo_ballenar", requiere="mapa_base_secta", interior_constante=True, zona="base_secta", nivel_zona=22)
        if i: unir(("wyn_base_entrada","wyn_base_depositos","wyn_base_celdas")[i-1],"norte",nid)
    unir("wyn_rompeolas","norte","wyn_base_entrada")

    # Lumensia y Slevferia conservan las funciones personales sin imponerlas.
    for nid, nombre, xy in (("lum_casa_elyra","Casa de Elyra",(1,2)),("lum_cementerio","Cementerio de Lumensia",(3,1)),("lum_jardin","Jardín de los patios",(2,1))):
        nodo(nid,nombre,xy,"LUM","bg_lumenia")
    unir("lum_posada","norte","lum_casa_elyra"); unir("lum_templo","oeste","lum_casa_elyra")
    unir("lum_archivo","norte","lum_cementerio"); unir("lum_cementerio","oeste","lum_jardin"); unir("lum_jardin","sur","lum_templo")
    nodo("slv_alindras","Sala de Alindras",(4,1),"SLV","bg_slevferia")
    unir("slv_taller","norte","slv_alindras")
    nodo("slv_canal","Canal de los artesanos",(5,2),"SLV","bg_slevferia")
    unir("slv_taller","este","slv_canal"); unir("slv_canal","sur","slv_camino")

    # Extenia tiene un submapa de palacio y una retirada real al muelle.
    nodo("ext_palacio_patio","Patio del palacio",(3,1),"EXT","bg_extenia")
    unir("ext_registro","norte","ext_palacio_patio")
    palacio = (
        ("ext_guardia","Puesto de guardia",(3,5),"palacio_acceso"),
        ("ext_corredor","Corredor del palacio",(3,4),"palacio_guardia_resuelta"),
        ("ext_laboratorio","Laboratorio de Destigio",(2,4),"palacio_guardia_resuelta"),
        ("ext_salon_rey","Salón del rey",(3,3),"destigio_registros"),
        ("ext_calabozo","Calabozo",(4,5),"palacio_acceso"),
        ("ext_pasaje","Pasaje de servicio",(4,4),"palacio_guardia_resuelta"),
        ("ext_cloacas","Cloacas",(2,3),"rey_derrotado"),
        ("ext_salida_cloacas","Salida al embarcadero",(1,3),"rey_derrotado"),
    )
    for nid,nombre,xy,req in palacio:
        nodo(nid,nombre,xy,"PALACIO","bg_extenia",requiere=req,interior_constante=True)
    unir("ext_palacio_patio","norte","ext_guardia"); unir("ext_guardia","norte","ext_corredor"); unir("ext_corredor","oeste","ext_laboratorio")
    unir("ext_corredor","norte","ext_salon_rey"); unir("ext_guardia","este","ext_calabozo"); unir("ext_calabozo","norte","ext_pasaje")
    unir("ext_pasaje","oeste","ext_corredor"); unir("ext_salon_rey","oeste","ext_cloacas"); unir("ext_cloacas","oeste","ext_salida_cloacas")

    # Quazelia: caminos protegidos, dos puntos de rescate fuera de ciudad.
    nodo("qaz_hangar","Hangar y escuela de vuelo",(3,1),"QAZ","bg_quazelia")
    unir("qaz_oficina","norte","qaz_hangar")
    nodo("qaz_costa","Costa del naufragio",(5,4),"QAZ","bg_playa_ballenar",salvaje=True,zona="quazelia_fauna",nivel_zona=30)
    unir("qaz_camino","sur","qaz_costa")
    nodo("qaz_puesto","Puesto de acogida",(5,2),"QAZ","bg_quazelia")
    unir("qaz_camino","norte","qaz_puesto"); unir("qaz_puesto","oeste","qaz_taller")
    nodo("qaz_boveda3","Bóveda 3",(6,2),"QAZ","bg_quazelia_bunker_entrada")
    unir("qaz_puesto","este","qaz_boveda3")

    # La aldea del regreso conserva la distribución que el jugador recuerda.
    # Mantener IDs heredados para admitir partidas anteriores sin cambiar la huida.
    for nid,nombre,xy,bg in (
        ("entrada_aldenbrock","Puente reparado · Aldenbrock",(4,1),"bg_puente_troll"),
        ("ald_bosque_regreso","Bosque gris · Regreso",(4,2),"bg_bosque_gris"),
        ("ald_claro_regreso","Claro de entrenamiento abandonado",(4,3),"bg_claro_entrenamiento"),
        ("plaza_aldenbrock","Plaza de Aldenbrock",(4,4),"bg_plaza_aldenbrock"),
        ("calle_oeste_aldenbrock","Patio tras el templo",(3,5),"bg_plaza_aldenbrock"),
        ("forja_aldenbrock","Forja de Bram",(5,4),"bg_forja_interior"),
        ("ald_habitacion_kael","Habitación de Kael",(6,4),"bg_habitacion_kael"),
        ("casa_mira_regreso","Casa de Mira y Miranda",(2,3),"bg_casa_mira"),
        ("casa_dorian_regreso","Casa de Dorian",(5,3),"bg_casa_dorian"),
        ("ald_huerto_regreso","Huerto entre malezas",(6,3),"bg_huerto_plantacion"),
        ("escuela_aldenbrock","Escuela abandonada",(3,3),"bg_escuela_interior"),
        ("boticaria_aldenbrock","Boticaria de Miranda",(2,4),"bg_boticaria_interior"),
        ("sotano_bram","Sótano de Bram",(5,5),"bg_sotano_bram"),
        ("ald_iglesia","Iglesia de Aldenbrock",(3,4),"bg_templo"),
        ("ald_camino_caballeros","Sendero de los caballeros",(7,4),"bg_bosque_gris"),
        ("ald_tumba_diara","Tumba de Diara",(7,5),"bg_bosque_gris"),
    ):
        nodo(nid,nombre,xy,"ALD_REGRESO",bg)
    for a,d,b in (
        ("entrada_aldenbrock","sur","ald_bosque_regreso"),
        ("ald_bosque_regreso","sur","ald_claro_regreso"),
        ("ald_claro_regreso","sur","plaza_aldenbrock"),
        ("ald_claro_regreso","oeste","escuela_aldenbrock"),
        ("ald_claro_regreso","este","casa_dorian_regreso"),
        ("casa_dorian_regreso","este","ald_huerto_regreso"),
        ("escuela_aldenbrock","oeste","casa_mira_regreso"),
        ("escuela_aldenbrock","sur","ald_iglesia"),
        ("ald_iglesia","este","plaza_aldenbrock"),
        ("ald_iglesia","oeste","boticaria_aldenbrock"),
        ("ald_iglesia","sur","calle_oeste_aldenbrock"),
        ("plaza_aldenbrock","este","forja_aldenbrock"),
        ("forja_aldenbrock","este","ald_habitacion_kael"),
        ("forja_aldenbrock","sur","sotano_bram"),
        ("ald_habitacion_kael","este","ald_camino_caballeros"),
        ("ald_camino_caballeros","sur","ald_tumba_diara"),
    ):
        unir(a,d,b)
    nodos["sotano_bram"]["requiere"] = "bram_sotano_completado"

    # Tres nodos del barco y recorrido final corto con retorno comunicado.
    for nid,nombre,xy,bg in (("barco_proa","Proa",(2,1),"bg_barco_proa"),("barco_camarotes","Camarotes",(2,2),"bg_barco_camarotes"),("barco_cubierta","Cubierta",(3,1),"bg_barco_combate")):
        nodo(nid,nombre,xy,"BARCO",bg,requiere="barco_operativo")
    unir("barco_proa","sur","barco_camarotes"); unir("barco_proa","este","barco_cubierta")
    for i,(nid,nombre) in enumerate((("fin_llegada","Claro de la expedición"),("fin_ruinas","Borde arrasado"),("fin_grieta","Cauce seco"),("fin_laboratorio","Entrada al laboratorio"),("fin_contenedor","Sala del contenedor"))):
        nodo(nid,nombre,(i+1,2),"FINAL","bg_continente_olvidado",zona="continente_olvidado",nivel_zona=40,salvaje=i in (1,2),interior_constante=i>=3)
        if i: unir(("fin_llegada","fin_ruinas","fin_grieta","fin_laboratorio")[i-1],"este",nid)

    return {"ciudades": CIUDADES, "nodos": nodos, "mapas": mapas}
