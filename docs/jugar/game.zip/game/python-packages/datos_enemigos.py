"""Validación compartida por Ren'Py y las herramientas locales de balance."""
import math

JOBS = {"tanque", "guerrero", "berserker", "ladron", "arquero", "mago", "curandero", "saboteador", "monje", "bestia", "maquinista", "oscuro"}
ELEMENTOS = {"fuego", "agua", "tierra", "aire", "luz", "sombra", None}
ARMAS = {"corte", "impacto", "punzante", "proyectil", "manolimpia"}
AFINIDADES = {"normal", "resiste", "debil", "nulo", "absorbe"}

def validar_catalogo(datos):
    def exigir(ok, mensaje):
        if not ok:
            raise ValueError("Catálogo de enemigos: " + mensaje)
    def entero(v):
        return isinstance(v, int) and not isinstance(v, bool)
    exigir(datos.get("version") == 1, "versión desconocida")
    exigir(isinstance(datos.get("enemigos"), dict) and bool(datos["enemigos"]), "enemigos vacío")
    exigir(isinstance(datos.get("items"), dict), "falta catálogo de objetos")
    for eid, d in datos["enemigos"].items():
        exigir(isinstance(eid, str) and eid.strip() == eid and bool(eid), "ID inválido")
        exigir(isinstance(d.get("nombre"), str) and bool(d["nombre"]), eid + ": nombre vacío")
        exigir(isinstance(d.get("zona"), str) and bool(d["zona"]), eid + ": zona vacía")
        exigir(d.get("job") in JOBS, eid + ": job inválido")
        exigir(d.get("elemento") in ELEMENTOS, eid + ": elemento inválido")
        exigir(d.get("arma") in ARMAS, eid + ": arma inválida")
        exigir(entero(d.get("nivel")) and 1 <= d["nivel"] <= 99, eid + ": nivel fuera de 1–99")
        exigir(isinstance(d.get("jefe", False), bool), eid + ": jefe debe ser booleano")
        exigir(isinstance(d.get("encuentro_aleatorio", True), bool), eid + ": encuentro_aleatorio debe ser booleano")
        exigir(isinstance(d.get("afin", {}), dict), eid + ": afinidades inválidas")
        for elemento, afin in d.get("afin", {}).items():
            exigir(elemento in ELEMENTOS - {None} and afin in AFINIDADES, eid + ": afinidad inválida")
        for campo in ("hp", "mp", "atk", "df", "agi", "mag", "mdef", "exp", "oro_min", "oro_max"):
            if campo in d:
                exigir(entero(d[campo]) and d[campo] >= (1 if campo == "hp" else 0), eid + ": " + campo + " inválido")
        exigir(d.get("oro_max", d.get("oro_min", 0)) >= d.get("oro_min", 0), eid + ": rango de oro invertido")
        exigir(isinstance(d.get("drops"), list), eid + ": drops debe ser lista")
        ids = set()
        for drop in d["drops"]:
            item = drop.get("item")
            exigir(item in datos["items"], eid + ": objeto desconocido " + str(item))
            exigir(item not in ids, eid + ": drop duplicado " + item)
            ids.add(item)
            prob = drop.get("probabilidad")
            exigir(isinstance(prob, (int, float)) and not isinstance(prob, bool) and math.isfinite(prob) and 0 <= prob <= 1, eid + ": probabilidad fuera de 0–1")
            minimo, maximo = drop.get("cantidad_min"), drop.get("cantidad_max")
            exigir(entero(minimo) and entero(maximo) and 1 <= minimo <= maximo <= 10, eid + ": cantidad fuera de 1–10")
            exigir(entero(drop.get("valor")) and drop["valor"] >= 0, eid + ": valor negativo")
            for campo in ("requiere_flag", "excluye_flag"):
                exigir(campo not in drop or isinstance(drop[campo], str), eid + ": bandera inválida")
    return True

def probabilidad_drop(base, bonus=0):
    # 0 nunca cae; 1 siempre cae. La suerte solo modifica probabilidades parciales.
    if base <= 0:
        return 0.0
    if base >= 1:
        return 1.0
    return min(.90, base + max(0, bonus))
