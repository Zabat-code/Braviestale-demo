"""Reglas de los arcos de ciudad, sin dependencia del motor ni estado global.

Cada cambio devuelve un estado nuevo: guardar/cargar y rollback no dependen de
modificar diccionarios de init ni de volver a entregar una escena terminada.
"""
from copy import deepcopy


def estado_inicial():
    return {'version': 1, 'arcos': {}, 'visitas': {}, 'trio': {}}


def migrar_estado(estado, arcos):
    resultado = deepcopy(estado) if isinstance(estado, dict) else estado_inicial()
    resultado.setdefault('arcos', {})
    resultado.setdefault('visitas', {})
    resultado.setdefault('trio', {})
    resultado['version'] = 1
    for mid, progreso in resultado['arcos'].items():
        if mid in arcos:
            progreso['paso'] = max(0, min(len(arcos[mid]['escenas']), int(progreso.get('paso',0))))
        progreso.setdefault('decisiones', {})
        progreso.setdefault('encuentros', [])
        progreso.setdefault('recompensa', False)
        progreso.setdefault('revisitas', 0)
    return resultado


def progreso_arco(estado, mid):
    return estado.get('arcos', {}).get(mid, {'paso':0, 'decisiones':{},
        'encuentros':[], 'recompensa':False, 'revisitas':0})


def requisitos_cumplidos(arco, estado, arcos, condiciones):
    return (all(progreso_arco(estado,mid)['paso'] >= len(arcos[mid]['escenas'])
                for mid in arco.get('requiere',[]))
            and all(condiciones.get(c,False) for c in arco.get('condiciones',[])))


def pendientes_nodo(datos, estado, nodo, condiciones):
    resultado = []
    for mid, arco in datos['arcos'].items():
        paso = progreso_arco(estado,mid)['paso']
        if (paso < len(arco['escenas']) and arco['escenas'][paso]['nodo'] == nodo
            and requisitos_cumplidos(arco,estado,datos['arcos'],condiciones)):
            resultado.append(mid)
    return resultado


def avanzar_escena(estado, mid, paso_esperado, arco, eleccion=None, encuentro=False):
    progreso = progreso_arco(estado,mid)
    if progreso['paso'] != paso_esperado or paso_esperado >= len(arco['escenas']):
        raise ValueError('La escena ya cambió: ' + mid)
    opciones = arco['escenas'][paso_esperado].get('opciones',[])
    if opciones and eleccion not in {o['id'] for o in opciones}:
        raise ValueError('Decisión no válida: ' + mid)
    resultado = deepcopy(estado)
    nuevo = deepcopy(progreso)
    if opciones:
        nuevo['decisiones'][str(paso_esperado)] = eleccion
    if encuentro:
        nuevo['encuentros'].append(paso_esperado)
    nuevo['paso'] += 1
    resultado['arcos'][mid] = nuevo
    return resultado


def marcar_recompensa(estado, mid, arco):
    progreso = progreso_arco(estado,mid)
    if progreso['paso'] != len(arco['escenas']) or progreso['recompensa']:
        return estado, False
    nuevo = deepcopy(estado)
    nuevo['arcos'][mid]['recompensa'] = True
    return nuevo, True


def validar_historias(datos, mundo, personajes_canon=()):
    if datos.get('version') != 1:
        raise ValueError('Versión de historias desconocida')
    personajes = set(datos['personajes']) | set(personajes_canon) | {'_', 'p'}
    for pid, ficha in datos['personajes'].items():
        if ficha['nodo'] not in mundo['nodos']:
            raise ValueError('Ubicación desconocida para ' + pid)
        if ficha['ciudad'] not in mundo['ciudades']:
            raise ValueError('Personaje nuevo fuera de las ciudades posteriores: ' + pid)
    for nid, reparto in datos['reparto'].items():
        if nid not in mundo['nodos'] or len(reparto) != len(set(reparto)):
            raise ValueError('Reparto inválido: ' + nid)
        if not set(reparto) <= set(datos['personajes']):
            raise ValueError('Residente sin ficha: ' + nid)
    for nid, ficha in mundo['nodos'].items():
        if ficha['region_campana'] in mundo['ciudades'] and not ficha.get('salvaje'):
            if len(datos['reparto'].get(nid,[])) < 2:
                raise ValueError('Menos de dos residentes: ' + nid)
    for mid, arco in datos['arcos'].items():
        if len(arco['escenas']) != 4 or not set(arco.get('requiere',[])) <= set(datos['arcos']):
            raise ValueError('Estructura inválida: ' + mid)
        for escena in arco['escenas']:
            if escena['nodo'] not in mundo['nodos']:
                raise ValueError('Escena sin lugar: ' + mid)
            for voz, frase in escena['lineas'] + sum((o['lineas'] for o in escena.get('opciones',[])),[]):
                if voz not in personajes or not frase.strip():
                    raise ValueError('Voz sin ficha: %s / %s' % (mid,voz))
            if 'opciones' in escena and len({o['id'] for o in escena['opciones']}) != len(escena['opciones']):
                raise ValueError('Decisión repetida: ' + mid)
        for voz, frase in arco['revisitas']:
            if voz not in personajes or not frase.strip():
                raise ValueError('Revisita sin voz: ' + mid)
    def visitar(mid, ruta):
        if mid in ruta:
            raise ValueError('Dependencias circulares: ' + mid)
        for previo in datos['arcos'][mid].get('requiere',[]):
            visitar(previo,ruta|{mid})
    for mid in datos['arcos']:
        visitar(mid,set())
    return True


def decidir_expedicion(trio, victoria_previa):
    """La rama se fija al aceptar el encargo, sin cronómetro ni cambio retrospectivo."""
    if trio.get('fase') not in ('formados','duelo'):
        raise ValueError('El equipo todavía no puede tomar el encargo')
    resultado=deepcopy(trio)
    resultado.update(fase='expedicion',victoria_previa=bool(victoria_previa),
        rama='regreso' if victoria_previa else 'desaparecidos')
    return resultado
