"""Nombres visibles de habitantes nuevos; los identificadores no se renombran."""
from copy import deepcopy
import re
import unicodedata


def nombre_normalizado(nombre):
    return ''.join(c for c in unicodedata.normalize('NFKD', nombre.casefold())
                   if not unicodedata.combining(c))


def reemplazador_nombres(reemplazos):
    """Sustituir palabras completas en una pasada, sin tocar IDs ni subcadenas."""
    cambios = {a: n for a, n in reemplazos.items() if a != n}
    if not cambios:
        return lambda texto: texto
    patron = re.compile(r'\b(?:' + '|'.join(re.escape(a) for a in
                        sorted(cambios, key=len, reverse=True)) + r')\b')
    return lambda texto: patron.sub(lambda m: cambios[m.group()], texto)


def aplicar_nombres_regionales(datos, perfiles):
    personajes = datos['personajes']
    cambios = perfiles['personajes']
    if set(personajes) != set(cambios):
        raise ValueError('El registro de nombres debe cubrir solo los NPC nuevos.')
    nombres = [nombre_normalizado(f['nombre']) for f in cambios.values()]
    if len(nombres) != len(set(nombres)):
        raise ValueError('Hay nombres visibles nuevos repetidos.')
    excluidos = {nombre_normalizado(n) for n in perfiles['excluidos']}
    if excluidos.intersection(nombres):
        raise ValueError('Hay un nombre descartado por Gerardo.')
    for pid, ficha in personajes.items():
        if ficha['nombre'] not in (cambios[pid]['anterior'], cambios[pid]['nombre']):
            raise ValueError('Nombre modificado fuera del registro: ' + pid)
    reemplazos = {f['anterior']: f['nombre'] for f in cambios.values()
                 if f['anterior'] != f['nombre']}
    sustituir = reemplazador_nombres(reemplazos)

    def textos(valor):
        if isinstance(valor, str):
            return sustituir(valor)
        if isinstance(valor, list):
            return [textos(v) for v in valor]
        if isinstance(valor, dict):
            return {k: textos(v) for k, v in valor.items()}
        return valor

    resultado = textos(datos)
    registro_anterior = datos.get('nombres_regionales', {})
    titulos = registro_anterior.get('titulos_anteriores') or {
        mid: a['titulo'] for mid, a in datos['arcos'].items()}
    resultado['nombres_regionales'] = {
        'version': perfiles['version'], 'reemplazos': reemplazos,
        'titulos_anteriores': titulos,
    }
    return resultado


def migrar_nombres_diario(misiones, eventos, datos):
    """Actualizar texto anterior conservando progreso, recompensas y otros diarios."""
    nuevas = deepcopy(misiones or {})
    entradas = deepcopy(eventos or [])
    registro = datos.get('nombres_regionales', {})
    sustituir = reemplazador_nombres(registro.get('reemplazos', {}))
    propios = set(datos['arcos']) | {
        'trio_arven', 'trio_ilis', 'trio_fael', 'trio_reencuentro',
        'trio_expedicion',
    }
    for mid, ficha in nuevas.items():
        if mid in propios:
            for campo in ('titulo', 'prosa', 'objetivo', 'cierre'):
                if isinstance(ficha.get(campo), str):
                    ficha[campo] = sustituir(ficha[campo])
    titulos = {'Misión: ' + anterior: 'Misión: ' + datos['arcos'][mid]['titulo']
               for mid, anterior in registro.get('titulos_anteriores', {}).items()
               if mid in datos['arcos']}
    trio = reemplazador_nombres({a: n for a, n in
        registro.get('reemplazos', {}).items() if a in ('Arven', 'Ilis', 'Fael', 'Halen')})
    for i, entrada in enumerate(entradas):
        if isinstance(entrada, dict) and isinstance(entrada.get('texto'), str):
            texto = entrada['texto']
            entrada['texto'] = trio(titulos.get(texto, texto))
        elif isinstance(entrada, str):
            entradas[i] = trio(titulos.get(entrada, entrada))
    return nuevas, entradas
