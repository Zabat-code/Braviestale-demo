"""Reglas puras de cuatro juegos con monedas ficticias de Braviestale."""
JUEGOS = ('moneda', 'dados', 'cubiletes', 'cartas')


def importe_valido(valor, saldo):
    if isinstance(valor, str):
        if not valor.isascii() or not valor.isdecimal():
            return None
        valor = int(valor)
    if type(valor) is not int or type(saldo) is not int or not 1 <= valor <= saldo:
        return None
    return valor


def crear_ronda(juego, apuesta, rng, percepcion=1):
    if juego not in JUEGOS or type(apuesta) is not int or apuesta < 1:
        raise ValueError('Juego o apuesta no válidos')
    r = {'juego':juego, 'apuesta':apuesta, 'resuelta':False}
    if juego == 'moneda':
        r['moneda'] = rng.choice(('cara','cruz'))
    elif juego == 'dados':
        r['dados'] = (rng.randint(1,6),rng.randint(1,6))
    elif juego == 'cubiletes':
        r['bola'] = rng.randint(1,3)
        prob = min(.90,.10+.02*max(1,min(100,int(percepcion))))
        r['pista_probabilidad'] = prob
        r['vaso_vacio'] = rng.choice([n for n in (1,2,3) if n != r['bola']]) if rng.random() < prob else None
    else:
        r['primera'] = rng.randint(2,8)
        r['segunda'] = rng.choice([n for n in range(1,10) if n != r['primera']])
    return r


def opciones(r):
    if r['juego'] == 'moneda': return ('cara','cruz','retirarse')
    if r['juego'] == 'dados': return ('bajo','alto','siete','retirarse')
    if r['juego'] == 'cubiletes': return tuple(str(i) for i in (1,2,3) if i != r.get('vaso_vacio')) + ('retirarse',)
    return ('mayor','menor','retirarse')


def cobro_cartas(r, eleccion):
    aciertos = 9-r['primera'] if eleccion == 'mayor' else r['primera']-1
    # Ocho segundas cartas posibles; 90% de retorno teórico antes del
    # redondeo. Se muestra el cobro concreto antes de elegir.
    return r['apuesta']*8*9//(10*aciertos)


def resolver_ronda(r, eleccion):
    if r.get('resuelta'):
        return dict(r['resultado'])
    if eleccion not in opciones(r):
        raise ValueError('Elección no válida')
    pago = 0; gana = False
    if eleccion == 'retirarse':
        detalle = 'Te retiraste de una mano ya apostada.'
    elif r['juego'] == 'moneda':
        gana = eleccion == r['moneda']; pago = r['apuesta']*2 if gana else 0
        detalle = 'La moneda cayó en '+r['moneda']+'.'
    elif r['juego'] == 'dados':
        total = sum(r['dados'])
        gana = (eleccion == 'bajo' and total < 7 or eleccion == 'alto' and total > 7 or eleccion == 'siete' and total == 7)
        pago = r['apuesta']*(5 if eleccion == 'siete' else 2) if gana else 0
        detalle = 'Dados: %d y %d; total %d.' % (*r['dados'],total)
    elif r['juego'] == 'cubiletes':
        gana = int(eleccion) == r['bola']; pago = r['apuesta']*2 if gana else 0
        detalle = 'La bola estaba bajo el cubilete %d.' % r['bola']
    else:
        gana = r['segunda'] > r['primera'] if eleccion == 'mayor' else r['segunda'] < r['primera']
        pago = cobro_cartas(r,eleccion) if gana else 0
        detalle = 'La segunda carta fue %d; la primera era %d.' % (r['segunda'],r['primera'])
    return {'gana':bool(gana), 'pago':pago, 'neto':pago-r['apuesta'], 'detalle':detalle, 'eleccion':eleccion}
