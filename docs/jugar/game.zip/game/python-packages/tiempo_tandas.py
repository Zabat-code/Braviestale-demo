"""Identificadores de eventos completados para el calendario de prueba."""
ESCENAS_ARCO = {
 'mira_regreso_casa':'etapa:mira:3', 'mira_curacion':'etapa:mira:4',
 'dorian_familia_regreso':'etapa:dorian:2', 'dorian_hector':'etapa:dorian:4',
 'bram_caballeros':'etapa:bram:3', 'bram_oficio':'etapa:bram:4',
 'wren_casa':'etapa:wren:2', 'wren_autonomia':'etapa:wren:3', 'wren_final':'etapa:wren:4',
 'sable_familia':'etapa:sable:3', 'sable_bote':'etapa:sable:4',
 'marek_despedida':'etapa:sable:4', 'elyra_belios':'etapa:elyra:4', 'theron_occam':'etapa:theron:final',
}
FLAGS_ARCO = {
 'mira_madre_congelada':'etapa:mira:3', 'alindras_cura_aprendida':'arco:alindras:tratamiento',
 'mira_suenos_hablados':'arco:mira:suenos', 'ysolda_acogida_hablada':'arco:ysolda:acogida',
 'ysolda_canto_hablado':'arco:ysolda:canto', 'ysolda_apuestas_recuerdo':'arco:ysolda:apuestas',
 'ysolda_amigo_presentado':'arco:ysolda:amigo', 'ysolda_amigo_sabe_muerte':'arco:ysolda:amigo_muerte',
 'ysolda_amigo_recuerdos':'arco:ysolda:recuerdos', 'ysolda_amigo_suenos':'arco:ysolda:amigo_suenos',
 'dorian_en_formacion':'arco:dorian:formacion', 'dorian_formacion_contacto':'arco:dorian:contacto',
 'dorian_formacion_regreso':'arco:dorian:regreso',
 'wren_visita_espiritu_luz':'arco:wren:templo', 'ralf_collar_bendecido':'arco:wren:templo',
 'theron_final_occam':'etapa:theron:final',
}
TRIO_CONTADORES=('arven_sesiones','ilis_paso','fael_paso')
TRIO_FASES={'formados','duelo','expedicion','regresaron','desaparecidos','encuentro_zombi','cerrado'}
LADRONES_FASES={'trato','plan','rescatado','jefe','fuga','vencidos'}


def eventos_nuevos(antes, actual):
    eventos=set()
    for pid,stage in actual.get('etapas',{}).items():
        if stage>antes.get('etapas',{}).get(pid,0): eventos.add('etapa:%s:%d'%(pid,stage))
    for mid,paso in actual.get('historias',{}).items():
        for n in range(antes.get('historias',{}).get(mid,0)+1,paso+1): eventos.add('historia:%s:%d'%(mid,n))
    for scene in set(actual.get('escenas',()))-set(antes.get('escenas',())):
        if scene in ESCENAS_ARCO: eventos.add(ESCENAS_ARCO[scene])
    for flag,event in FLAGS_ARCO.items():
        if actual.get('flags',{}).get(flag) and not antes.get('flags',{}).get(flag): eventos.add(event)
    a=actual.get('trio',{}); old=antes.get('trio',{})
    for counter in TRIO_CONTADORES:
        for n in range(old.get(counter,0)+1,a.get(counter,0)+1): eventos.add('trio:%s:%d'%(counter,n))
    if a.get('fase')!=old.get('fase') and a.get('fase') in TRIO_FASES: eventos.add('trio:fase:'+a['fase'])
    # La fiesta cierra una fase; no es otro cargo por el mismo cierre.
    if a.get('fiesta_vista') and not old.get('fiesta_vista'): eventos.add('trio:fase:cerrado')
    for pid,state in actual.get('romance',{}).items():
        if state in ('pareja','roto') and state!=antes.get('romance',{}).get(pid): eventos.add('romance:%s:%s'%(pid,state))
    ld=actual.get('ladrones')
    if ld in LADRONES_FASES and ld!=antes.get('ladrones'): eventos.add('ladrones:'+ld)
    # Puesto/familia final de Theron se marcan juntos en el controlador de campaña.
    if 'etapa:theron:final' in eventos: eventos.discard('etapa:theron:4')
    return sorted(eventos)


def eventos_previos(actual):
    eventos=set(eventos_nuevos({},actual))
    for pid,stage in actual.get('etapas',{}).items():
        for n in range(1,stage+1): eventos.add('etapa:%s:%d'%(pid,n))
    if actual.get('etapas',{}).get('theron',0)>=4 and actual.get('flags',{}).get('theron_final_occam'):
        eventos.add('etapa:theron:final')
    return sorted(eventos)
